# CHANGELOG REPORTING FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## 1.4

Version 1.4 

Fixed menu to work on new installation
Export feature works with sheets

