<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class XMLProcessingException
 */
class XMLProcessingException extends ReaderException
{
}
