<?php
echo '<h3>Marketing</h3>';
echo $obj->read('marketing', $_REQUEST);