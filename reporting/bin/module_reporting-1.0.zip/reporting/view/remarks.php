<?php
echo '<h3>Management Remarks</h3>';
echo $obj->read('remarks', $_REQUEST);
?>