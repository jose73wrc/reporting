<?php
echo '<h3>Present-Forward</h3>';
echo $obj->read('forward', $_REQUEST);