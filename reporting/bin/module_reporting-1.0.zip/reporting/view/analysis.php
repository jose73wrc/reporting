<?php
echo '<h3>Analysis</h3>';
echo $obj->read('analysis', $_REQUEST);