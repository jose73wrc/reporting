<?php
echo '<h3>Sales & Operations</h3>';
echo $obj->read('sales', $_REQUEST);